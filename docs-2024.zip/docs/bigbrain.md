
1. What was the concept of the Big Brain Theory in human evolution?

  - The idea that to find the link, one had to find such brain that was about larger than the ape brain, but around smaller than the human one. This would prove that the human main charistaristic, in the evolutionary path was the brain size. 

2. What Did Donald Johanson name his fossil discovery in East Africa?

- Lucy
- Just older that certain periods. She walked on two legs not fourth. 

3. How did Donald Johanson's discovery invalidate the Big Brain theory of human evolution?

  - Pelvis no mammal had around same size, that they had walked in two legs. Volcanic ash, Just like ours walking.
  - Lucy's brain was too small. It was about the size of the American softball. 1/3 1/4 size
  - Lucy with a very small brain, but also bipedal.  Separated brain size, conflict that resolves quicky, dated using radioactive dating techniques. 
  - Lucy 3 million old
  - 1470 could be descendant Big brain was million younger.
  - Now realizing that bipedalism became the great iconic fossil. 
  - The ad

4. How did bipedalism contribute to to the development of large brains in hominins (human ancestors)?

  - Front legs became hands
  - Had to outweigh the speed slow impeded by primitive bipedalism
  - manipulation of things that quadrupeds didn't
	  - Led to technology
	  - Stimulus of larger brains
	  - New ways of communication -> Complex Societies and cultures. 
	  - Better food, better diet, 

5. Near the end of the video the narrator states that human evolution did not occur in a separate fashion from other animals. Rather, human evolution occurred through adaptive radiation just like all other animals. What does this mean?

- Ecological Niches, slightly better way to give the population new areas, and specifies, 
- Adaptive radiations, 
	- They diversified from common ancestors to niche adaptations, lots of related species, 
	- It seems that didn't have adaptive radiation, but just a straight line. Except Lucy species. Super creatures. 
	- Radiation, and this makes sense because 
	- Shifted to walk with our skull correctly. 
	- Face on humans are flat. around the mid face. 
	- Possible that were different species. 
	- In humans are about the same, 
	- Flat Face Man. 
	- After replacement of grassland, one of these, being apes, that could walk in two legged animals, that could walk in the. Eventually becoming Human 

----

1. What was the concept of the Big Brain Theory in human evolution?

 The idea of the Big Brain Theory was around that for Human Evolution, the enlargement of the brain was the first key characteristic.

2. What Did Donald Johanson name his fossil discovery in East Africa?

The name of the fossil discovered by Johanson was Lucy. Which was proved to relate to an hominid ancestor, as it was the only mammal pelvis fossil that indicated bipedalism

3. How did Donald Johanson's discovery invalidate the Big Brain theory of human evolution?

  Johanson's discovery challenged the Big Brain theory by revealing that bipedalism preceded significant brain enlargement in hominins. Lucy's small brain size (around a softball size) contradicted the notion that increased brain size was a prerequisite for bipedalism.

4. How did bipedalism contribute to to the development of large brains in hominins (human ancestors)?

  Front legs became hands, allowing focus on the manipulation of items, which led to better technology, that was the stimulus of larger brains. Which allowed a cycle of new ways of communication and support for more complex civilizations.

5. Near the end of the video the narrator states that human evolution did not occur in a separate fashion from other animals. Rather, human evolution occurred through adaptive radiation just like all other animals. What does this mean?

This means that Lucy wasn't the only candidate ancestor, as after Lucy another ancestor candidate was identified (Flat Face Man), this is evidence that human evolution wasn't the exception of the adaptive radiation pattern that can be seen in other animals (such as the big cat family example).

