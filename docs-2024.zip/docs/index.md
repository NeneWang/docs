---
home: true

tagline: Personal Projects Docs. 
actionText: Get Started
actionLink: /guide/
heroImage: https://avatars.githubusercontent.com/u/29577570?v=4

features:
- title: Projects
  details: Projects and Templates for future use,
- title: Journals
  details: Personal Journal from the developer.
footer: Nelson Wang since 8.10.2021
---

