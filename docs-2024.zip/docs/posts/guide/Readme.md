---
title: ✍️ Guide
---



[[toc]]

## Introduction

 - Using my programming experience, this is going to be biased towards programmers.
 - Also Will use my Skills to create tools to help people.
 - This is a work in progress, so it will be updated as I learn more.
 - Examples will be provided for the current time I am writing this, but I hope to make each tip/principle as time independent as possible.


## Organization

- Will be divided in large categories such as career | family | finance. 
- Tips will be started as bullet points. So it can be developed in the future.

## Disclaimer

- The resources listed will be my objectively the best options.
- I wont claim that the following build will work for anyone, so please refer to my biologic stats for debugging.
- Some of them will be tools developed by me, but probably will be free tools, as my goal is to help people.
- This is actually an opinionated guide, so please take it with a grain of salt.


## Biologic Stats

- Asian, 5'11'' or 181cm
- IQ hovering around 120-130


![](https://media.giphy.com/media/XD9o33QG9BoMis7iM4/giphy.gif)










