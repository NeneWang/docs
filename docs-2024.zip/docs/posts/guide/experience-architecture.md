# Experience in Software Architecture

## Core Inisghts

Practical Lessons to always have in all projects

1. Good software is to be written at least twice
2. Utilize a template that comes with the following:
  - Auto Documentation Engine
  - Auto Testing System
  - Dockerization/Package Publishing Template
3. Don't over engineer. But DO engineer your software










