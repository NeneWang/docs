---
title: 👨‍👩‍👧‍👦 Family
tags: guide
---


[[toc]]

## Introduction



## Partner

1. Document, take Photos, Video recordings, Immortalize these beautiful moments
   1. Dont be dumb like me and snapchat, probably lost a lot of content so far
   2. Your memory is not perfect, and you WILL forget Please keep track of these little things.
   3. Create a Youtube blog to support and memo what the life is.
   4. Your younger days will never come back. So take photos, keep them in memory
   5. Encourage usage of videos to record. Save them online for memory as well.
2. Enjoy and perform *Weekly Dates*.


**Projects**

For [1] Create some kind of memory folder with all these beautiful moments as a *support system*.
Try to also create your own blog with your partner when it comes to this projects.

For [2] Develop a wheel with all the weekly images that are being sent.

It would be interesting to develop some kind of software that takes in a snapchat-like request to be sent photos, and memories.
You could prototype that concept using `Be Real`





