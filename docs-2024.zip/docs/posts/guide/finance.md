---
title: 💸 Personal Finance
---


[[toc]]

## Introduction

Includes:

- Investing
- Minimizing Expenses
- Budgeting and managing Subscriptions.



### Investing


When selecting a share search for the following:

- Non biased structure, based on meritocracy. Check Hirings Program what are they looking for Are they looking for junior engineers? Do they ask for skills or there is an agenda behind it?.
- Are they outsourcing? If they are, it means they are not able to do it themselves. It's a red flag.
- Are they working remote? If they are, then it means they are not collaborating. It's a red flag.
- Strong Financials Basics, Making more money than they spend.
- Compare the Earnings Per Share (EPS) with the industry standard. Check if that makes sense.
- Managers to Workers Ratio. Are they just retaining people because of seniority? Or are they retaining people because they are good at what they do? How are business politics?













