---
title: 🌱 Personal Growth
---


[[toc]]

Includes:

1. Learning
2. Self Taught
3. Discipline Strategies
4. Workout and Nutrition.
5. Self Improvement Habits


## 1. Workout While Watching Shows


:::tip Summary

- Lightly Workout while watching shows. With Abs, etc. Great workouts are:
  - Rope Jumping
  - Abdominals
  - One Leg Squats
  - Squats
  - Train Machine
- Great Series to watch are:
  - Shounen Animes

:::


- How many time have we spent watching shows?
- What if we could workout while watching shows?
- Some workouts I like are:
  - Rope Jumping
  - Abdominals
  - One Leg Squats
  - Squats
  - Train Machine
- NEVER watch a show wihout working out
- Great for before taking a shower. 

## 2. Have a Focusmate

- Use Focusmate to create a daily schedule
- Stick to it
- include Research about having an accountability partner


## 3. Use Current School Programs as an opportunity to make projects and deadlines.

- Always go beyond
- If it is too easy use it to learn more about the topic on your own.
- Always do the projects, and personal projects from what you have learned.
- Use the school as a way to create deadlines for your projects.


## 4. If you cant practice it, then you won't learn it



- Use tools like Anki
- Or show your custom tool
- Repetition is the mother of all learning
- Make it easy, dont make your practice writing a 250 words essay
- Is okay to make mistakes on practice, encourage it.
- Creating an habit or automating the practice schedule.


## 5. Reading is Great, But Practice is Better

- Being able to reach to practice is better than reading.
- Reading Serves well as a guide
- Video Lectures in some cases are better than books because is about how much can we get as inputs, and video lectures are more engaging.
- For Practical skills like programming, reading is not enough, we need to practice.
- You should even have the habit of creating flashcards using Anki or other tools from the books main points.




## 6. Hold Certifications for passive long-term practice

1. Should optimize for Certifications and Interview level questions regarding a topic. 
   1. Search common interview topics about it. 
   2. Or Certification problems with sample answers.
   3. Or Books with questions regarding it.
   4. Or Courses Examples with questions regarding it.

I would try to apply for the following certifications once I am done with School:

*The main advantages here, is to store some money to be able to take on this certifications*

- CFA Level 1
- AWS Certified Cloud Practitioner
- AWS Certified Solutions Architect – Associate
- AWS Certified Developer – Associate
- Oracle Certified Associate, Java SE 8 Programmer
- Google IT Support Professional Certificate
- CFA Level 2
- AWS Certified Solutions Architect – Professional
- CISCO
- Red Hat Certified Engineer
- Certified Secure Software Lifecycle Professional (CSSLP)


- Also try to get that gov. security clearance
- You might want to join the military for that.








