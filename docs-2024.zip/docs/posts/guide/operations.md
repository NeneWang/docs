---
tagline: How would I operate create a new Company? What areas and what type of Culture?
title: Business Operations
---


This are some notes for the date you want to develop a corporate.

## 1 Categorization and Time

For corporate each categorization of usability time depends on the following:
- How much does someone directly contribute? What's the KPI?
- For example for knowledge based strategic workers. The KPI is the amount of smart decisions they can produce.
  - Encourage going back to school part-time, and work hard the other half time.
  - Write good letters



## 2 Hiring

- Hire for hunger. some expertise, some credentials. Mainly for hunger. And look for patterns of hungriness.


## 3. Caring Culture

- If a dev or associate doesn't believe in the product being built. Then they wont be able to 100%. Avoid hiring, or try to make them believe in the product.



### 4. Creating Templates

**Create Templates for Understanding each Client Requirements**

- Can be a google forms

**Create Templates for your Audience Segments**

For the Web Agency then:

- Book Publishers
- Small Business
- Game Publishers
- Channels/Influencers

Here are largest amounts of low effort ( new business ) that might immediately try to need a site. That might be underserved.


**Offer Template Services depending on the Industry the client is at**

### 6. Versioning

**Iterate Weekly document weekly progress Here**

- You can write that either here on `code-documentation` and then add all those feature releases into the GitHub release notes.

### 7. Customer Attendance
*Here some general rules*

1. Write "Received, will be processing" as soon as things are sent.
2. Try to make each iteration take around 1-2 business days.
3. Create a Notion website containing their private project and their feature request and a links and all resources allocated to that project. As well as the contract and fees.

To investigate
- Does Notion Premium features cost more than Obsidians?
- How about using this same documentation git repository to only publish a specific public-contract folder so that I don't have to move vault from vault and is all in one place?
- Would this make sense until I find a better way to display these documentation docs?
















