---
title: Others
---


[[toc]]

## Introduction



Here more miscellaneous tips such as:

- Giving presentations
- Writing Blogs
- Being Creative.





