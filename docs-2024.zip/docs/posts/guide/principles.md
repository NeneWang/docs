---
title: ⚖️ Principles
lang: en-US
---

[[toc]]

## Introduction

Usually tips included here are applicable to most disciplines.

Includes:
1. General Tips


## 1. Document Everything.

:::tip Summary

:::

- Just like this documentation you should have one for yourself.
- Note for example the following Documentation Journal I have: [Journal](/journal/)

## 2. Use Decision Matrix

- Stuck?
- Use a Decision Matrix to help you decide.
- A decision matrix exmample:
- Create a tool/application for quick decision Matrix Development

- Create a copy of this on wireframing



## 3.Finding Research

- Use Google Images and find `chart looking` images.
- Those for some reason link to the original source.
- Use General Famous Books
  - They often are a good source of studies and research to support their arguments.



## 4. Have an Edit and Review Process

- Edit Process
  - In Edit process you dont judge yor content
  - Bullet points are geat way to have conscice points
- Review Process
  - In Review process you judge your content
  - Ask people for help for second eyes.
  - Is when you start treaming work.


## 5. Integrate New Technology, Stay on top.

1. Use AI, and coding, and any other new technology that might be applied. Such as online learning, or VR for learning skillsets



## 6. 





















