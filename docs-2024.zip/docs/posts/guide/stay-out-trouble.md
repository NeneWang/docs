---
title: Staying out of trouble
---



## 1. Security Troubles

- IP Address Limitation
- Queries are separated by organization and access by user?

## 2. Logic Trouble

- What would be logically errors from the processing?





