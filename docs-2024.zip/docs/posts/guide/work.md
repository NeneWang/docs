---
title: Work
---

This handles mostly Work politics, philosophy and tips to ascend the corporate ladder.



## 1. Prepare Ahead


**Prepare Pre-meeting Sticky notes after finishing all your tasks**
Always have Sticky Notes of what to talk on the next meeting.

1. What to work on next? What about modeling?
2. If you are focusing on your work, you will naturally generate ideas regarding how to improve the framework


**Prepare After Meetings Actionable Comments and Cards**

e.g. You discussed about designing feature: New Api Models, Bug found at X in a meeting.

Then, after meeting, you should write something like:
Hi,  should I create the following ticket cards and documentation derived from the meeting we had today? (Trello Board)
- New Api Models:

```bash
User:
- name: Updated feature
- username: Added Username.
```




## 2. Take it personally

**Work and lead your company to success.**

1. You don't want to be mediocre life.
   1. You will learn a lot in the journey as well.
   2. You wont feel ashamed of participating and objecting ideas.
2. A company will help you if you hold it's success in your best interest. 
   1. Recommendation letters for education.
   2. Education + Training
   3. Loyalty
3. Burn Passion and you will advanced the most educationally speaking as well.



