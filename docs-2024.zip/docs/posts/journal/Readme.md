---
title: Dev Journal
---

# Introduction

- This is more of a debug dump notes. Probably not expected to be deployed. 
- Or at least privately deployed (for personal use.) This is nice to (in the future) track productivity + debugging and maintaining one-self motivated while developing (Also makes debugging faster). 
- As well as easier to explain errors and get assistance. Thus, perhaps worth deploying somewhere.
- Could be used as an unlisted journal notes.

It will contain all my code dumps. Including for a specific project, since I tend to switch projects a lot. If we are trying to update regarding features and interesting decision (Actual documentation) please refer to the projects section.

How to avoid leak though? Perhaps keeping it private and deploying it to custom server? Also might be important to limit read access using keys. And references to other documentations would be also sensical to keep it private. While the projects You DO want to keep it public ? 

Table of Contents
[[toc]]



## Discussion Board

### What can be included here?

More or less this can even serve as a catch-all for including all the work that it's neither a project or a anything else













