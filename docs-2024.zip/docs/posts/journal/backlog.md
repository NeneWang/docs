---
tagline: Backlog for tasks to research etc. Also link to
---


### Trello Links


### Documentation Work to be performed here

- [ ] Include and document all projects currently being worked
- [ ] Create Client side portal to review their work project. (It can be done using the paid thing.)

### To Research

- [ ] I wonder if there is an option for markdown + json only backend?

### Books to Include here