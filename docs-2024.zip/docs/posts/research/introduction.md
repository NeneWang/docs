
- Research and Documentation of topics that I seem to be interested.
- This folder is intended to be public.
- This might be collated together with 
- The project might not be 100% related to software

**What's different from the Project Section?**

- Not market/business performance oriented.
- Might had been already charted territory, or just a collection of bibliographies.


Here some questions that I would like to Genuinely Answer and Document:

Currently working on:

- Genetic Algorithms and Human Anthropology
- Graph Algorithms

Backlog:

- Software that won't become obsolete.
- Genetic Algorithms and In the Business World
- 

