
# Introduction


- This section is intended to be case studies of projects being worked on. 
- This are business oriented paid projects, personal Projects.
- Will be published for sharing.


TBD
- Might have interlocked links with the ones found at Journal (That are hidden?)


Expect the following structure:
- Case Studies and background.
- Market Oriented Market Research and Ux Research.
- Features and Releases.
- Performance and Analytics over time.

For example: [15.1 Continue Working On Chrome Extension](../journal/24-3-mar.md#15.1%20Continue%20Working%20On%20Chrome%20Extension)



### Backlog

**Current Projects**

2024-03-15
- SLC Website
- Panda Plus


**Backlog**

- Sticker Website
- 





